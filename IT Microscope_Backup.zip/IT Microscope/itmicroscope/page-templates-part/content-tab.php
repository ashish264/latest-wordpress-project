<div class="section_list text-center">
        <div class="container">
          <ul>
            <li><a href="http://www.quotewerks.com/ViewDemo.asp" target="_blank"><i class="flaticon-road"></i> Take a tour</a></li>
            <li><a href="http://www.quotewerks.com/prodinfo.asp" target="_blank"><i class="flaticon-verification-of-delivery-list-clipboard-symbol"></i> Product Information</a></li>
            <li><a href="http://www.quotewerks.com/reqdemo.asp" target="_blank"><i class="flaticon-interface"></i> Download free Trial</a></li>
          </ul>
        </div>
      </div>