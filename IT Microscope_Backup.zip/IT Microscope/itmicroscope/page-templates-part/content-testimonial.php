<section class="comn_sec testimonial_sec">
        <div class="container">
            <div class="comn_head">
                <h4>Testimonials</h4>
                <span>Testimonials</span>
              </div>
        <div class="row">
        	<?php 
        		$args = array('post_type'=> array('testimonial'), 'posts_per_page' => 2, 'post_status' => 'publish');
        		$testimonials = new WP_Query($args);
        		if($testimonials->have_posts()){
        			while($testimonials->have_posts()){
        				$testimonials->the_post();
        				$image_url = get_template_directory_uri().'/assets/images/No_image_available.svg';
        				if(has_post_thumbnail())
        					$image_url = get_the_post_thumbnail_url(get_the_ID(), array(170,170));
        				?>
						<div class="col-sm-6">
							<div class="testimonial_box">
								<!-- <div class="testimonial_img">

									<img src="<?php// echo $image_url; ?>" alt="<?php //the_title(); ?>">
								</div> -->
								
								<p><span class="before_quote"></span><?php echo get_the_content(); ?><span class="after_quote"></span></p>
								<span><?php// echo get_the_date( 'd/m/Y' ); ?></span>
								<h4><?php the_title(); ?></h4>
							</div>
						</div>
        				<?php
        			}
        			wp_reset_postdata();
        		}else{
        			echo '<p>No testimonial found!</p>';
        		}

        	?>
        </div>
        </div>

      </section>