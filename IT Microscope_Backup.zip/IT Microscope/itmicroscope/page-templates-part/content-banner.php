 <section class="product_banner inner_banner banner_color" style="background-image: url(<?php echo CFS()->get( 'banner_image' ); ?>);">
                <div class="banner_data">
                    <h1><?php echo CFS()->get('banner_heading'); ?></h1>
                    <p><?php echo CFS()->get('banner_description'); ?></p>
                </div>
  </section>