<?php get_header(); ?>

Hello Ashis

<?php get_footer(); ?>